import React from 'react';

const ChangePassword = () => {
    return (
        <div>
            <h1>CHANGE PASSWORD PAGE!</h1>
        </div>
    );
};

export default ChangePassword;