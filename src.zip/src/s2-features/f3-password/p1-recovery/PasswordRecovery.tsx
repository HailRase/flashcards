import React from 'react';

const PasswordRecovery = () => {
    return (
        <div>
            <h1>PASSWORD RECOVERY PAGE!</h1>
        </div>
    );
};

export default PasswordRecovery;