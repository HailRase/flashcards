import React from 'react';

const E404 = () => {
    return (
        <div>
            <h1>ERROR 404! PAGE NOT FOUND!</h1>
        </div>
    );
};

export default E404;