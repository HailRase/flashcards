export const profileReducer = (state: any = {}, action: any): any => {
    switch (action.type) {
        default:
            return state
    }
}