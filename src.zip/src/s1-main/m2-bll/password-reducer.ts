export const passwordReducer = (state: any = {}, action: any): any => {
    switch (action.type) {
        default:
            return state
    }
}